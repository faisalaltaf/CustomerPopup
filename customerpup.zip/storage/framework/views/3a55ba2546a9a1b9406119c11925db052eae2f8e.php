

<?php $__env->startSection('content'); ?>
<div class="Polaris-Frame__ContextualSaveBar Polaris-Frame-CSSAnimation--startFade"></div>
<div class="Polaris-Frame__Content">
                <div class="Polaris-Page">
                  <div class="Polaris-Page-Header Polaris-Page-Header--isSingleRow Polaris-Page-Header--mobileView Polaris-Page-Header--noBreadcrumbs Polaris-Page-Header--mediumTitle">
                    <div class="Polaris-Page-Header__Row">
                      <div class="Polaris-Page-Header__TitleWrapper">
                        <div>
                          <div class="Polaris-Header-Title__TitleAndSubtitleWrapper">
                              <br>
                            <!--<h1 class="Polaris-Header-Title">Form</h1>-->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="Polaris-Page__Content">
                      
                    <div class="Polaris-Layout">
                        <a id="SkipToContentTarget" tabindex="-1"></a>
                        <!-------table code-->
                      <div style="width:100%;">
                        <div>
                            <div class="Polaris-Card">
                              <div class="Polaris-IndexTable">
                               
                                <div class="Polaris-IndexTable-ScrollContainer">
                                  <table class="Polaris-IndexTable__Table Polaris-IndexTable__Table--unselectable" style="text-align: left; width:100%; padding:15px;">
                                    <thead>
                                      <tr style="border-bottom:1px sloid gray;">
                                        <th class="Polaris-IndexTable__TableHeading Polaris-IndexTable__TableHeading--second Polaris-IndexTable__TableHeading--unselectable" data-index-table-heading="true">#Id</th>
                                        <th class="Polaris-IndexTable__TableHeading Polaris-IndexTable__TableHeading--unselectable" data-index-table-heading="true">Email</th>
                                        <th class="Polaris-IndexTable__TableHeading Polaris-IndexTable__TableHeading--unselectable" data-index-table-heading="true">Marketing Audience</th>
                                        <th class="Polaris-IndexTable__TableHeading Polaris-IndexTable__TableHeading--last Polaris-IndexTable__TableHeading--unselectable" data-index-table-heading="true">Issue Date</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr class="Polaris-IndexTable__TableRow Polaris-IndexTable__TableRow--unclickable">
                                        <td class="Polaris-IndexTable__TableCell"><span class="Polaris-TextStyle--variationStrong">Mae Jemison</span></td>
                                        <td class="Polaris-IndexTable__TableCell">Decatur, USA</td>
                                        <td class="Polaris-IndexTable__TableCell">20</td>
                                        <td class="Polaris-IndexTable__TableCell">$2,400</td>
                                      </tr>
                                      <tr class="Polaris-IndexTable__TableRow Polaris-IndexTable__TableRow--unclickable">
                                        <td class="Polaris-IndexTable__TableCell"><span class="Polaris-TextStyle--variationStrong">Ellen Ochoa</span></td>
                                        <td class="Polaris-IndexTable__TableCell">Los Angeles, USA</td>
                                        <td class="Polaris-IndexTable__TableCell">30</td>
                                        <td class="Polaris-IndexTable__TableCell">$140</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                              <div class="Polaris-IndexTable__ScrollBarContainer">
                                <div class="Polaris-IndexTable__ScrollBar" style="--p-scroll-bar-content-width:736px;">
                                  <div class="Polaris-IndexTable__ScrollBarContent"></div>
                                </div>
                              </div>
                            </div>
                            <div id="PolarisPortalsContainer"></div>
                          </div>
                
                      </div>
                    <!-------table code end---->
                    </div>   
                  </div>
                </div>
              </div>

            </main>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\customerpup\resources\views/audience_list.blade.php ENDPATH**/ ?>