

<?php $__env->startSection('content'); ?>
<main class="Polaris-Frame__Main" id="AppFrameMain" data-has-global-ribbon="false">
              <div class="Polaris-Frame__Content">
                <div class="Polaris-Page">
                  <div class="Polaris-Page-Header Polaris-Page-Header--isSingleRow Polaris-Page-Header--mobileView Polaris-Page-Header--noBreadcrumbs Polaris-Page-Header--mediumTitle">
                    <div class="Polaris-Page-Header__Row">
                      <div class="Polaris-Page-Header__TitleWrapper">
                        <div>
                          <div class="Polaris-Header-Title__TitleAndSubtitleWrapper">
                           <!----- <h1 class="Polaris-Header-Title">Welcome To Dashboard</h1>-->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="Polaris-Page__Content">
                      
                    <div class="Polaris-Layout">
                        <a id="SkipToContentTarget" tabindex="-1"></a>
                        <!-----  welcome text---->
                        <div class="Polaris-Layout__AnnotatedSection">
                            <div class="Polaris-Layout__AnnotationWrapper">
                              <div class="Polaris-Layout__Annotation">
                                <div class="Polaris-TextContainer">
                                  <h2 class="Polaris-Heading">Welcome To Dashboard</h2>
                                </div>
                              </div>
                             
                            </div>
                          </div>
                    
                    </div>   
                  </div>
                </div>
              </div>
            </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\customerpup\resources\views/dashboard.blade.php ENDPATH**/ ?>