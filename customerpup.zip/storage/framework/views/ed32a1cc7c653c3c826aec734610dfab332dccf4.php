

<?php $__env->startSection('content'); ?>


  
<div class="Polaris-Frame__Content">
                <div class="Polaris-Page">
                  <div class="Polaris-Page-Header Polaris-Page-Header--isSingleRow Polaris-Page-Header--mobileView Polaris-Page-Header--noBreadcrumbs Polaris-Page-Header--mediumTitle">
                    <div class="Polaris-Page-Header__Row">
                      <div class="Polaris-Page-Header__TitleWrapper">
                        <div>
                          <div class="Polaris-Header-Title__TitleAndSubtitleWrapper">
                              <br>
                            <h1 class="Polaris-Header-Title">Form</h1>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="Polaris-Page__Content">
                      
                    <div class="Polaris-Layout">
                        <a id="SkipToContentTarget" tabindex="-1"></a>
                        <!----- logo img-->
                        <div class="Polaris-Layout__AnnotatedSection">
                            <div class="Polaris-Layout__AnnotationWrapper">
                              <div class="Polaris-Layout__Annotation">
                                <div class="Polaris-TextContainer">
                                  <h2 class="Polaris-Heading">Logo</h2>
                                  <p>Customize the style of your Logot</p>
                                </div>
                              </div>
                              <div class="Polaris-Layout__AnnotationContent">
                                <div class="Polaris-Card">
                                  <div class="Polaris-Card__Section">
                                    <div class="Polaris-SettingAction">
                                      <div class="Polaris-SettingAction__Setting">
                                        Upload your store’s logo, change colors and fonts, and
                                        more.
                                      </div>
                                      <div class="Polaris-SettingAction__Action">
                                        <button type="button" class="Polaris-Button Polaris-Button--primary">
                                          <span class="Polaris-Button__Content"><span>Upload logo</span></span>
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        

                         <!------heading---->
                         <div class="Polaris-Layout__AnnotatedSection">
                            <div class="Polaris-Layout__AnnotationWrapper">
                              <div class="Polaris-Layout__Annotation">
                                <div class="Polaris-TextContainer">
                                  <h2 class="Polaris-Heading" id="Heading">Heading</h2>
                                  <div class="Polaris-Layout__AnnotationDescription">
                                    <p>Enter your Heading.</p>
                                  </div>
                                </div>
                              </div>
                              <div class="Polaris-Layout__AnnotationContent">
                                <div class="Polaris-Card">
                                  <div class="Polaris-Card__Section">
                                    <div class="Polaris-FormLayout">
                                      <div class="Polaris-FormLayout__Item">
                                        <div class="">
                                          <div class="Polaris-Labelled__LabelWrapper">
                                            <div class="Polaris-Label"><label id="PolarisTextField1Label" for="PolarisTextField1" class="Polaris-Label__Text">Heading</label></div>
                                          </div>
                                          <div class="Polaris-Connected">
                                            <div class="Polaris-Connected__Item Polaris-Connected__Item--primary">
                                              <div class="Polaris-TextField Polaris-TextField--hasValue">
                                                  <input id="PolarisTextField1" autocomplete="email" class="Polaris-TextField__Input" type="Text" aria-labelledby="PolarisTextField1Label" aria-invalid="false" value="Enter heading">
                                                <div class="Polaris-TextField__Backdrop"></div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                        <!-----List items-->
                      <div class="Polaris-Layout__AnnotatedSection">
                        <div class="Polaris-Layout__AnnotationWrapper">
                          <div class="Polaris-Layout__Annotation">
                            <div class="Polaris-TextContainer">
                              <h2 class="Polaris-Heading">List Items</h2>
                              <div class="Polaris-Layout__AnnotationDescription">
                                <p>Enter your list item text.</p>
                              </div>
                            </div>
                          </div>
                          <div class="Polaris-Layout__AnnotationContent">
                            <div class="Polaris-Card">
                              <div class="Polaris-Card__Section">
                                <div class="Polaris-FormLayout">
                                  <div class="Polaris-FormLayout__Item">
                                    <div class="">
                                      <div class="Polaris-Labelled__LabelWrapper">
                                        <div class="Polaris-Label">
                                            <label id="PolarisTextField2Label" for="PolarisTextField2" class="Polaris-Label__Text">List Items</label></div>
                                      </div>
                                      <div class="Polaris-Connected">
                                        <div class="Polaris-Connected__Item Polaris-Connected__Item--primary">
                                          <div class="Polaris-TextField Polaris-TextField--hasValue">
                                              <input id="PolarisTextField2" autocomplete="New sales every day" class="Polaris-TextField__Input" type="" aria-labelledby="PolarisTextField2Label" aria-invalid="false" value="New sales every day">
                                            <div class="Polaris-TextField__Backdrop"></div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                       <!-----Email-->
                       <div class="Polaris-Layout__AnnotatedSection">
                        <div class="Polaris-Layout__AnnotationWrapper">
                          <div class="Polaris-Layout__Annotation">
                            <div class="Polaris-TextContainer">
                              <h2 class="Polaris-Heading">Email</h2>
                              <div class="Polaris-Layout__AnnotationDescription">
                                <p>Enter your Email Address.</p>
                              </div>
                            </div>
                          </div>
                          <div class="Polaris-Layout__AnnotationContent">
                            <div class="Polaris-Card">
                              <div class="Polaris-Card__Section">
                                <div class="Polaris-FormLayout">
                                  <div class="Polaris-FormLayout__Item">
                                    <div class="">
                                      <div class="Polaris-Labelled__LabelWrapper">
                                        <div class="Polaris-Label"><label id="PolarisTextField3Label" for="PolarisTextField3" class="Polaris-Label__Text">Email</label></div>
                                      </div>
                                      <div class="Polaris-Connected">
                                        <div class="Polaris-Connected__Item Polaris-Connected__Item--primary">
                                          <div class="Polaris-TextField Polaris-TextField--hasValue"><input id="PolarisTextField2" autocomplete="email" class="Polaris-TextField__Input" type="email" aria-labelledby="PolarisTextField3Label" aria-invalid="false" value="dharma@jadedpixel.com">
                                            <div class="Polaris-TextField__Backdrop"></div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                        <!-----button-->
                        <div class="Polaris-Layout__AnnotatedSection">
                            <div class="Polaris-Layout__AnnotationWrapper">
                              <div class="Polaris-Layout__Annotation">
                                <div class="Polaris-TextContainer">
                                  <h2 class="Polaris-Heading">Button</h2>
                                  <div class="Polaris-Layout__AnnotationDescription">
                                    <p>Enter your Button Text.</p>
                                  </div>
                                </div>
                              </div>
                              <div class="Polaris-Layout__AnnotationContent">
                                <div class="Polaris-Card">
                                  <div class="Polaris-Card__Section">
                                    <div class="Polaris-FormLayout">
                                      <div class="Polaris-FormLayout__Item">
                                        <div class="">
                                          <div class="Polaris-Labelled__LabelWrapper">
                                            <div class="Polaris-Label"><label id="PolarisTextField4Label" for="PolarisTextField4" class="Polaris-Label__Text">Button</label></div>
                                          </div>
                                          <div class="Polaris-Connected">
                                            <div class="Polaris-Connected__Item Polaris-Connected__Item--primary">
                                              <div class="Polaris-TextField Polaris-TextField--hasValue">
                                                  <input id="PolarisTextField4" autocomplete="Enter Heading" class="Polaris-TextField__Input" type=" " aria-labelledby="PolarisTextField4Label" aria-invalid="false" value="Continue">
                                                <div class="Polaris-TextField__Backdrop"></div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                    </div>   
                  </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\customerpup\resources\views/setting.blade.php ENDPATH**/ ?>